# ShieldSquare
#### Real-time Bot Management Solution for Web Apps, Mobile & APIs

On integrating ShieldSquare's PHP connector, it will start making API calls to ShieldSquare solution and the response received is in the form of a response code. The response code directly indicates the action to be taken based on the incoming request. All API calls made to ShieldSquare are by default asynchronous in nature(monitor mode)

Release Version : 6.1.10
### Requirements
- PHP v5.3+
- CURL v7.29+
- Server [apache 2.2/2.4, Nginx 1.9.0 - 1.17.0]

### Integration
- Install PHP, CURL and Other dependencies for ShieldSquare Connector to work. Packages to install - `php, php-common, curl, php-fpm`.
- Download PHP connector zip from ShieldSquare FTI form.
- Extract the downloaded PHP connector zip. It extracts a folder `ss_php_v6.x.x`.
- The extracted `ss_php_v6.x.x` folder contains `Sample_Files` folder, `ShieldSquare_API` folder and a README.md file.
- Folder Tree Structure:
```
  ├── README.md
  ├── Sample_Files
  │   ├── sample_active.php
  │   └── sample_monitor.php
  └── ShieldSquare_API
      ├── config
      │   ├── ss2_config.json
      │   └── shieldsquare_cfg.json
      ├── lib
      │   ├── ss2classes.php
      │   └── ss2constants.php
      ├── ss2.php
      └── utils
          ├── ss2curlhandler.php
          ├── ss2getconfig.php
          ├── ss2logg.php
          ├── ss2utils.php
          └── sslcert
              └── ShieldsquareCABundle.pem
```
- Kindly copy `ShieldSquare_API` folder into your project to integrate ShieldSquare module.
- After copying the `ShieldSquare_API` folder in to your project, the following API code snippet needs to be added to the common header file of your website.
- For example if you have a common php file for your project, say `header.php`. Then the `header.php` file should look like,
```
<?php
    # ShieldSquare API Code Snippet
    include "../ShieldSquare_API/ss2.php";  #Path to include your ShieldSqare_API/ss2.php file;
    $username = "Sample Username";
    $shieldsquare_response = shieldsquare_validaterequest($username);
    echo $shieldsquare_response->responsecode;

    .....
      YOUR CODE HERE
      .....
```
- Allow Our Plugin to Update its Config File by granting folder Permissions and SeLinux Permissions.
```
$ sudo chmod -R 0777 /your project path/ShieldSquare_API/config/
$ sudo chcon -t httpd_sys_rw_content_t /your project path/ShieldSquare_API/config/ss2_config.json
$ sudo chcon -t httpd_sys_rw_content_t /your project path/ShieldSquare_API/config/shieldsquare_cfg.json
```
- Refer to the sample files from the downloaded kit for clear understanding.
- `shieldsquare_validaterequest()` function returns an object with a response code.

What is a Response Code?
- Response code is an integer value which defines the request type. It will allow you to take action against the user request.

|Response Code|Request Type|
|:----------:|:----------:|
| 0 | Valid Request |
| 2 | Show Captcha  |
| 3 | Block Request |
| 4 | Feed Fakedata |
| -1 |  ShieldSquare Error |

### Support
For Feedback or any questions, please reach out to our support team at [support@shieldsquare.com](mailto:support@shieldsquare.com).

### Release History

Release v6.0.10, March 2019
- Username Parameter Passing Support
- Minor Bug fixes

Release v6.1.0, May 2019
- Version F
- Username Support

Release v6.1.1, August 2019
- Nginx Support

Release v6.1.4, September 2019
- PHP 5.3 Support
- Bug Fixes

Release v6.1.5, December 2019
- Bug Fixes
- Advance Bot Codes

Release v6.1.6, Feb 2020
- IP Mismatch
- ATO 
- BugFixes

Release v6.1.8, May 2020
- IP Mismatch Encoding Update
- ATO Cookies Fix
- Packet Splitting Bug Fix

Release v6.1.9, June 2020
- Fix for PID value generation logic.

Release v6.1.10, August 2020
- Version updated.