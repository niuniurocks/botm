<?php

class ShieldsquareAPIPacket
{
    public $_zpsbd0 = false;
    public $_zpsbd1 = "";
    public $_zpsbd2 = "";
    public $_zpsbd3 = "";
    public $_zpsbd4 = "";
    public $_zpsbd5 = "";
    public $_zpsbd6 = "";
    public $_zpsbd7 = "";
    public $_zpsbd8 = "";
    public $_zpsbd9 = "";
    public $_zpsbda = "";
    public $_zpsbdt = "";
    public $_zpsbdp = 70000;
    public $_zpsbdm = "";
    public $_zpsbdx = "";
    public $_zpsbdxrw = "";
    public $__uzma = "";
    public $__uzmb = 0;
    public $__uzmc = "";
    public $__uzmd = 0;
}

class ShieldsquareAPIResponseJson
{
    public $message = "";
    public $ss2resp = "";
}

class ShieldsquareValidateResponse
{
    public $pid = "";
    public $url = "";
    public $reason = "";
    public $responsecode = "";
    public $dynamic_JS = "";
    public $__uzdbm_1 = "";
    public $__uzdbm_2 = "";
}

class SIEMLogs
{
    public $IP = "";
    public $UA = "";
    public $URL = "";
    public $Referrer = "";
    public $Session = "";
    public $Username = "";
    public $ResponseTime = "";
}

?>
