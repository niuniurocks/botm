<?php

class ShieldsquareValidIPRange
{
    public $minIP1 = '10.0.0.0';
    public $maxIP1 = '10.255.255.255';
    public $minIP2 = '172.16.0.0';
    public $maxIP2 = '172.31.255.255';
    public $minIP3 = '192.168.0.0';
    public $maxIP3 = '192.168.255.255';
    public $minIP4 = '127.0.0.0';
    public $maxIP4 = '127.255.255.255';
    public $minIP5 = '198.18.0.0';
    public $maxIP5 = '198.19.255.255';
    public $minIP6 = '100.64.0.0';
    public $maxIP6 = '100.127.255.255';
    public $minIP7 = '192.0.0.0';
    public $maxIP7 = '192.0.0.255';
}

class ShieldsquareCodes
{
    public $ALLOW_EXP = -1;
    public $ALLOW = 0;
    public $MONITOR = 1;
    public $CAPTCHA = 2;
    public $BLOCK = 3;
    public $FFD = 4;
    public $COMPLEX_JS = 5;
    public $SLEEP = 6;
    public $DROP =7;
    public $TERMINATE_SESSION = 8;
    public $LOOP = 9;
    public $LOG_RESP = 10;
    public $CUSTOM_RESP = 11;
    public $MED_CAPTCHA = 21;
    public $HARD_CAPTCHA = 22;
}

class ShieldsquareActions {
    public $RESP_CAPTCHA = array(2,21,22);
    public $RESP_WITH_QUERYSTR = array(3,7,9);
    public $RESP_FOR_LOG = array(-1, 0, 1, 4, 5, 8, 10, 11);
}


class ShieldsquareConstants
{
    public $CONNECTOR_ID = "PHP v6.1.10";
    public $SS_COUNTER = 1;
    public $DEFAULT_VERSION = -1;
    public $CALLTYPE_DEFAULT = 1;
    public $MOBILE = 6;
    public $TIME_LENGTH = 10;
    public $UZMC_LENGTH = 12;
    public $UUID_LENGTH = 36;
    public $API_CALL_TIMEOUT = 2000;
    public $COOKIE_EXPIRY = 15552000;
    public $API_REFRESH_TIME = 300;
    public $API_DEFAULT_TIMEOUT_OUT = 1000;
    public $SUPPORT_EMAIL = "support@shieldsquare.com";
    public $INFO = "info";
    public $DEBUG = "debug";
    public $ERROR = "error";
    public $WARNING = "warning";
    public $NOTICE = "notice";
    public $GET_CONFIG = "configuration";
    public $GET_VERSION = "version";
    public $ERROR_LOG_FILE_NAME = "shieldsquare_php.log";
    public $ERROR_LOG_FILE_SIZE = 5242880;
    public $ERROR_LOG_FILE_LIMIT = 5;
    public $log_dirname = "/tmp/";
    public $ss2filename = "ss2_config.json";
    public $cfgfilename = "shieldsquare_cfg.json";
    public $DEFAULT_SLEEP_TIME = 2000; // ms
    public $DEFAULT_ATO_CALLTYPE = 71;
}

class ShieldsquareRequestConstants
{
    public $shieldsquare_l = 10000;
    public $shieldsquare_h = 99999;
    public $shieldsquare_a = 1;
    public $shieldsquare_b = 3;
    public $shieldsquare_c = 7;
    public $shieldsquare_d = 1;
    public $shieldsquare_e = 5;
    public $shieldsquare_f = 10;
}

class ShielsquareQueryConstants
{
    public $digits = '0123456789';
    public $charDigits = '0123456789abcdef';
    public $charDigits1 = '0123456abcdefghkizlmp';
    public $charString = 'abcdefghijk@lmnop';
    public $charDigits2 = 'pqrstuv234219993232@lmnop';
    public $alternateUserAgent = array(
        "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)",
        "Mozilla/4.0 (Windows NT 5.1) AppleWebKit/535.7 (KHTML,like zeco) Chrome/33.0.1750.154 Safari/536.7",
        "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1) Gecko/20100101 Firefox/39.0",
        "Mozilla/5.0 (compatible; Yahoo! Slurp; http://help.yahoo.com/help/us/ysearch/slurp)",
        "Chrome/5.0 (iPhone; U; CPU iPhone OS 3_0 like Mac OS X; en-us) AppleWebKit/528.18 (KHTML, like Gecko) Version/4.0 Mobile/7A341 Safari/528.16"
    );
}

?>
