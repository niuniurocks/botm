<?php

include 'lib/ss2classes.php';
include 'lib/ss2constants.php';
include 'utils/ss2curlhandler.php';
include 'utils/ss2getconfig.php';
include 'utils/ss2logg.php';
include 'utils/ss2utils.php';


function shieldsquare_validaterequest($username) {
    return validaterequest($username);
}

function shieldsquare_Protect($username, $user_calltype, $action=null, $action_status=null) {
    $ss_constants = new ShieldsquareConstants();
    $user_calltype = intval($user_calltype) != 0 ? intval($user_calltype) : $ss_constants->DEFAULT_ATO_CALLTYPE;
    return validaterequest($username, $user_calltype, $action, $action_status);
}

function validaterequest($username, $user_calltype=null, $action=null, $action_status=null)
{
    $current_time = time();
    $responsedata = new ShieldsquareValidateResponse();
    $returncodes = new ShieldsquareCodes();
    $actionarrays = new ShieldsquareActions();
    $reqconstants = new ShieldsquareRequestConstants();
    $ss_constants = new ShieldsquareConstants();
    $ss2log = new ss2Log();

    $init_config_file_path = dirname(__FILE__) . "/config/" . $ss_constants->ss2filename;
    $cfm_config_file_path = dirname(__FILE__) . "/config/" . $ss_constants->cfgfilename;

    $config_data = get_config($init_config_file_path, $cfm_config_file_path);

    if ($config_data == NULL || empty($config_data)) {
        $responsedata->reason = "API Server Response is Empty";
        $responsedata->responsecode = $returncodes->ALLOW_EXP;
        return $responsedata;
    }

    $ss2log::$log_enabled = $config_data->_log_enabled == "False" ? false : true;
    $ss2log::$log_dirname = $config_data->_file_write_location != '' ? $config_data->_file_write_location : '';

    $isSecure = false;
    if ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https') || (isset($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') || (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443) ) {
        $isSecure = true;
    }

    $schema = $isSecure ? 'https://' : 'http://';
    $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '';
    $path = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
    $reqURL = $schema . $host . $path;

    $skipurl_filter = skipurlfilter($config_data, $reqURL);
    $extension_filter = extensionfilter($config_data, $reqURL);
    if ($skipurl_filter || $extension_filter) {
        $responsedata->reason = "Requestfilter/Skipurl matched. Skipping Request.";
        $responsedata->responsecode = $returncodes->ALLOW;
        return $responsedata;
    }

    $postserviceurl = post_service_url($config_data);
    $config_pid = generate_pid($config_data->_sid);
    $expirytime = $current_time + $ss_constants->COOKIE_EXPIRY;
    $sessionid = $config_data->_sessid;

    $responsedata->pid = $config_pid;
    $responsedata->url = $reqURL;
    $mode = $config_data->_mode === 'Active' ? true : false;
    $calltype = intval($config_data->_calltype) != 0 ? intval($config_data->_calltype) : $ss_constants->CALLTYPE_DEFAULT;

    $apipacket = new ShieldsquareAPIPacket();
    if ($user_calltype != null) {
        $calltype = $user_calltype;
        $mode = false;
        $apipacket->_action = $action != null ? $action : "";
        $apipacket->_action_status = $action_status != null ? $action_status : "";
    }
    $apipacket->_zpsbd0 = $mode;
    $apipacket->_zpsbd1 = $config_data->_sid;
    $apipacket->_zpsbd2 = $config_pid;
    $apipacket->_zpsbd3 = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '';
    $apipacket->_zpsbd4 = $reqURL;
    $apipacket->_zpsbd5 = isset($_COOKIE[$sessionid]) ? $_COOKIE[$sessionid] : '';
    $apipacket->_zpsbd6 = get_request_ip($config_data->_ipaddress);
    $apipacket->_zpsbd7 = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
    $apipacket->_zpsbd8 = $calltype;
    $apipacket->_zpsbd9 = $username;
    $apipacket->_zpsbda = $current_time;
    $apipacket->_zpsbdt = $ss_constants->CONNECTOR_ID."-".$config_data->_version;
    $apipacket->_zpsbdp = intval(isset($_SERVER['REMOTE_PORT']) ? $_SERVER['REMOTE_PORT'] : '70000');
    if ($config_data->_other_headers == "True") {
        $other_headers = get_other_headers($config_data);
        if (!empty($other_headers)) {
            $apipacket->_zpsbdx = $other_headers;
        }
    }

    validate_iSplitIP($apipacket, $config_data->_ip_index);
    validate_proxy_authorization($apipacket);
    validate_ajax_headers($apipacket);
    validate_IP_headers($apipacket, $config_data->_deployment_number);
    validate_cookies($apipacket, $current_time, $expirytime, $config_data);

    $apipacket_json = json_encode($apipacket);
    $ss2log->ss2_log("Json Packet [" . $apipacket_json . "]", $ss_constants->DEBUG);

    $serviceurl = $postserviceurl;
    $json = $apipacket_json;
    $curltime = isset($config_data->_api_server_timeout) ? $config_data->_api_server_timeout : $ss_constants->API_DEFAULT_TIMEOUT_OUT;

    if ( ($mode === true)
        || ( $mode === false && ($config_data->_async_http_post == "False"))) {
        $response_code = handle_sync($config_data, $serviceurl, $json, $curltime);
    } else {
        $response_code = handle_async($config_data, $serviceurl, $json, $curltime);
    }

    $responsedata->responsecode = $response_code;
    $responsedata->dynamic_JS = "var __uzdbm_c = 2+2";

    if ($calltype == $ss_constants->MOBILE) {
        if (($config_data->_ss_captcha_enabled == 'True' && $response_code == $returncodes->CAPTCHA)
            || ($config_data->_ss_block_enabled == 'True' && $response_code == $returncodes->BLOCK)) {
            $uzmcr = (mt_rand(1, 100) * 4) + $response_code;
            header('uzmcr:' . $uzmcr);
        }
        $posturl = $config_data->_posturl;
        if ($posturl != NULL) {
            header('posturl:' . $posturl);
        }
        $trackevent = $config_data->_trkevent;
        if ($trackevent == "True") {
            header('trkevent:' . $trackevent);
        }
    }
    else if ($response_code === $returncodes->SLEEP) {
        $sleep_time = $config_data->_sleep_time;
        if (!isset($sleep_time) || !intval($sleep_time)){
            $sleep_time = $ss_constants->DEFAULT_SLEEP_TIME;
        }
        $ss2log->ss2_log("Sleep for $sleep_time milli seconds.", $ss_constants->DEBUG);
        $sleep_time = (int)$sleep_time;
        usleep($sleep_time * 1000);
    }
    elseif (in_array($response_code, $actionarrays->RESP_CAPTCHA) ||
            in_array($response_code, $actionarrays->RESP_WITH_QUERYSTR)) {
        $scheme = $config_data->_api_server_ssl_enabled == "True" ? 'https://' : 'http://';
        $redirectdomain_d = $config_data->_d_redirect_domain;
        $redirectdomain_c = $config_data->_redirect_domain;
        $customresp = preg_match('~' . $redirectdomain_d . '~', $redirectdomain_c) ? false : true;
        $querystring = generate_redirect_query($apipacket, $config_data, $reqconstants->shieldsquare_e, $reqconstants->shieldsquare_f, $customresp,$response_code);
        $redirecturl = $scheme . $redirectdomain_c . $querystring;
        $ss2log->ss2_log("Redirecting to  [" . $redirecturl . "]", $ss_constants->DEBUG);
        header('Location:' . $redirecturl);
        exit();
    }
    else{
        if (in_array($response_code, $actionarrays->RESP_FOR_LOG)) {
            $ss2log->ss2_log("Action Code: $response_code ", $ss_constants->DEBUG);
        } else {
            $ss2log->ss2_log("Unkown/New Action Code: $response_code ", $ss_constants->DEBUG);
        }
    }
    /* JS IPAddres mismatch. Add uzma and encrpyted pid with ip address
       as two different js variables, so that js connector pick this
       and send it with js params to backend. Backend can corelate things
       with the help of IP, uzma and pid. 

       Data is build with pid and ip address with $ as a seperator. 
       There is a encoder key configured (default is available too), 
       and a 10digit random key is generated by the connector. 
    */ 

    $dataToEncode = $apipacket->_zpsbd2 . '$' . $apipacket->_zpsbd6;

    $responsedata->__uzdbm_2 = base64_encode($dataToEncode);
    $responsedata->__uzdbm_1 = $apipacket->__uzma;

    $ss2log->ss2_log("ShieldSquare Response [" . json_encode($responsedata) . "]", $ss_constants->DEBUG);
    return $responsedata;
}

?>
