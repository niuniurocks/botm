<?php
function initial_config($filename)
{
    $ss2log = new ss2Log();
    $ss_constants = new ShieldsquareConstants();
    $initial_config = NULL;
    if (file_exists($filename)) {
        try {
            $initial_config = json_decode(file_get_contents($filename));
            $ss2log::$log_dirname = $initial_config->_file_write_location != '' ? $initial_config->_file_write_location : '';
            $ss2log->ss2_log("Initial config [" . json_encode($initial_config) . "]", $ss_constants->DEBUG);
            return $initial_config;
        } catch (Exception $e) {
            $ss2log->ss2_log("File read exception [" . $e->getMessage() . "]", $ss_constants->ERROR);
            return $initial_config;
        }
    } else {
        $ss2log->ss2_log("Initial config file not found", $ss_constants->ERROR);
        return $initial_config;
    }
}

function get_config($ic_filename, $configpath)
{
    $ss2log = new ss2Log();
    $ssconsts = new ShieldsquareConstants();
    $config_data = NULL;

    if (file_exists($configpath)){
        try {
            $config_data = json_decode(file_get_contents($configpath));
        } catch (Exception $e) {
            $ss2log->ss2_log("File read exception [" . $e->getMessage() . "]", $ssconsts->ERROR);
            $config_data = NULL;
        }
    }

    if ($config_data != NULL){
        $current_time = time();
        $cexpire_time = $config_data->_clasttime;
        $life = $current_time - $cexpire_time;
        if ($life > $ssconsts->API_REFRESH_TIME) {
            $initial_config = initial_config($ic_filename);
            $version1 = isset($config_data->_version) ? intval($config_data->_version) : $ssconsts->DEFAULT_VERSION;
            $version2 = read_version_from_api($initial_config);
            if ($version1 == $ssconsts->DEFAULT_VERSION || (isset($version2) && $version2 > $version1)) {
                $config_data = read_config_from_api($ic_filename, $initial_config, $configpath);
            } else {
                $ss2log->ss2_log("Updating config time", $ssconsts->DEBUG);
                $config_data->_clasttime = time();
                write_config_to_file($configpath, $config_data);
            }
        }
    } else {
        $initial_config = initial_config($ic_filename);
        if ($initial_config == NULL) {
            $ss2log->ss2_log("Initial config file is empty!", $ssconsts->ERROR);
            return NULL;
        }
        $ss2log->ss2_log("Config does not exists! Reading config from API server", $ssconsts->DEBUG);
        $config_data = read_config_from_api($ic_filename, $initial_config, $configpath);
    }

    return $config_data;
}

function read_version_from_api($initial_config)
{
    $ss2log = new ss2Log();
    $consts = new ShieldsquareConstants();
    $req = $consts->GET_VERSION;
    $serviceurl = get_service_url($initial_config, $req);
    $key = $initial_config->key;
    $ss2log->ss2_log("Reading version from ShieldSquare API server [" . $serviceurl . "]", $consts->DEBUG);
    $config_data = perform_curl($initial_config, $serviceurl, $key);
    $version = isset($config_data->_version) ? intval($config_data->_version) : $consts->DEFAULT_VERSION;
    return $version;
}

function read_config_from_api($ic_filename, $initial_config, $configpath)
{
    $ss2log = new ss2Log();
    $conf_data = NULL;
    $ss_constants = new ShieldsquareConstants();
    $req = $ss_constants->GET_CONFIG;
    $serviceurl = get_service_url($initial_config, $req);
    $key = $initial_config->key;
    $ss2log->ss2_log("Reading config from ShieldSquare API server [" . $serviceurl . "]", $ss_constants->DEBUG);
    $config_data = perform_curl($initial_config, $serviceurl, $key);
    if ($config_data == NULL || empty($config_data)) {
        return NULL;
    }

    $conf_data = $config_data;
    update_initial_config($ic_filename, $conf_data, $initial_config);

    $conf_data->_clasttime = time();
    $conf_data->_deployment_number = $initial_config->deployment_number;
    write_config_to_file($configpath, $conf_data);

    return $conf_data;
}

function write_config_to_file($filename, $config_data){
    $ss2log = new ss2Log();
    $ss_constants = new ShieldsquareConstants();
    try{
        $wfile = fopen($filename, "w");
    } catch(Exception $e){
        $ss2log->ss2_log("Exception occured:[".$e->getMessage()."]", $ss_constants->ERROR);
    }

    if($wfile !== FALSE){
        if(flock($wfile, LOCK_EX)){
            fwrite($wfile, json_encode($config_data));
            fflush($wfile);
            flock($wfile, LOCK_UN);
        }
        else{
            $ss2log->ss2_log("Could not get the lock on [".$filename."]", $ss_constants->INFO);
        }
    } else {
        $ss2log->ss2_log("File is not opened: [".$filename."]", $ss_constants->INFO);
    }

    if($wfile) {
        fclose($wfile);
    }
}

function update_initial_config($ic_filename, $conf_data, $initial_config){
    $ss2log = new ss2Log();
    $ss_constants = new ShieldsquareConstants();
    $cfgflag = false;
    $initial_config_write = $initial_config;
    if (($conf_data->_api_server_domain != NULL) && ($initial_config->api_server_domain != $conf_data->_api_server_domain)) {
        $initial_config_write->api_server_domain = $conf_data->_api_server_domain;
        $cfgflag = true;
    }
    if (($conf_data->_api_server_timeout != NULL) && ($initial_config->api_server_timeout != $conf_data->_api_server_timeout)) {
        $initial_config_write->api_server_timeout = $conf_data->_api_server_timeout;
        $cfgflag = true;
    }
    if (($conf_data->_api_server_ssl_enabled != NULL) && ($initial_config->api_server_ssl_enabled != $conf_data->_api_server_ssl_enabled)) {
        $initial_config_write->api_server_ssl_enabled = $conf_data->_api_server_ssl_enabled;
        $cfgflag = true;
    }
    if (($conf_data->_file_write_location != NULL) && ($initial_config->_file_write_location != $conf_data->_file_write_location)) {
        $initial_config_write->_file_write_location = $conf_data->_file_write_location;
        $cfgflag = true;
    }
    if ($cfgflag) {
        try {
            file_put_contents($ic_filename, json_encode($initial_config_write));
            $ss2log->ss2_log("Updating ss2_config.json config file", $ss_constants->DEBUG);
        } catch (Exception $e) {
            $ss2log->ss2_log("Exception in updating config file [" . $e->getMessage() . "]", $ss_constants->ERROR);
        }
    }
}

?>
