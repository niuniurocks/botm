<?php

define('JSON_UNESCAPED_SLASHES', 64);

function perform_curl($ss2config_data, $url, $key)
{
    $ss2log = new ss2Log();
    $ss_constants = new ShieldsquareConstants();
    $curlresp = false;
    try {
        $curl = curl_init();
    } catch (Exception $e) {
        $ss2log->ss2_log("Initialising curl failed [" . $e->getMessage() . "]", $ss_constants->ERROR);
        return NULL;
    }
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json', 'Authorization:Bearer ' . $key));
    curl_setopt($curl, CURLOPT_NOSIGNAL, 1);
    if ($ss2config_data->api_server_ssl_enabled == "True") {
        $pemfile = dirname(__FILE__) . '/sslcert/ShieldsquareCABundle.pem';
        if (file_exists($pemfile)) {
            curl_setopt($curl, CURLOPT_CAPATH, $pemfile);
            curl_setopt($curl, CURLOPT_CAINFO, $pemfile);
        } else {
            $ss2log->ss2_log("SSL Certificate is Missing ! " . $pemfile . " Not Found ", $ss_constants->ERROR);
        }
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 1);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2);
    }
    curl_setopt($curl, CURLOPT_TIMEOUT_MS, $ss2config_data->api_server_timeout);
    try {
        $curlresp = curl_exec($curl);
    } catch (Exception $e) {
        $ss2log->ss2_log("Error in curl execution [" . $e->getMessage() . "]", $ss_constants->ERROR);
    }
    if ($curlresp === false || empty($curlresp)) {
        $ss2log->ss2_log("Error reading data [" . curl_error($curl) . " , " . curl_errno($curl) . "]", $ss_constants->ERROR);
        curl_close($curl);
        return NULL;
    }
    curl_close($curl);
    $config_data = NULL;
    try {
        $config_data = json_decode($curlresp);
        $config_data = json_encode($config_data->data, JSON_UNESCAPED_SLASHES);
        $config_data = json_decode($config_data);
    } catch (Exception $e) {
        $ss2log->ss2_log("Error decoding response json [" . curl_error($curl) . " , " . curl_errno($curl) . "]", $ss_constants->ERROR);
        return $config_data;
    }
    return $config_data;
}

function shieldsquare_sync($config_data, $url, $params, $timeout)
{
    $ss2log = new ss2Log();
    $ss_constants = new ShieldsquareConstants();
    $response_obj = new ShieldsquareAPIResponseJson();
    $post_data = $params;
    try {
        $curl = curl_init();
    } catch (Exception $e) {
        $errormessage = "Initialising curl failed [" . $e->getMessage() . "]";
        $ss2log->ss2_log($errormessage, $ss_constants->ERROR);
        $response_obj->message = $errormessage;
        return $response_obj;
    }
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_HTTPHEADER, array('Expect: ','Content-Type: application/json', 'Content-Length:' . strlen($post_data)));
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $post_data);
    curl_setopt($curl, CURLOPT_NOSIGNAL, 1);
    curl_setopt($curl, CURLOPT_TIMEOUT_MS, $timeout);
    curl_setopt($curl, CURLOPT_HEADER, 1);

    if ($config_data->_api_server_ssl_enabled == "True") {
        $pemfile = dirname(__FILE__) . '/sslcert/ShieldsquareCABundle.pem';
        if (file_exists($pemfile)) {
            curl_setopt($curl, CURLOPT_CAPATH, $pemfile);
            curl_setopt($curl, CURLOPT_CAINFO, $pemfile);
        } else {
            $ss2log->ss2_log("SSL Certificate is Missing ! " . $pemfile . " Not Found ", $ss_constants->WARNING);
        }
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 1);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2);
    }

    if (isset($config_data->_is_http_proxy) && ($config_data->_is_http_proxy == "True")) {
        $proxy = (string)($config_data->_proxy_address . ":" . $config_data->_proxy_port);
        curl_setopt($curl, CURLOPT_PROXY, $proxy);
        if ($config_data->_is_proxy_auth == "True") {
            $proxyauth = (string)($config_data->_proxy_username . ":" . $config_data->_proxy_password);
            curl_setopt($curl, CURLOPT_PROXYUSERPWD, $proxyauth);
        }
    }
    $ss2log->ss2_log("Sending data to the ShieldSquare server " . $url, $ss_constants->DEBUG);
    try {
        $sendTime = round(microtime(true) * 1000);
        $content = curl_exec($curl);
        $recTime = round(microtime(true) * 1000);
        $respTime = $recTime - $sendTime;
        $ss2log->ss2_log("Response from ShieldSquare server " . $content, $ss_constants->DEBUG);
        $header_size = curl_getinfo($curl, CURLINFO_HEADER_SIZE);
        $headers = substr($content, 0, $header_size);
        $headers = explode("\r\n", $headers);
        $headers = array_filter($headers);
        $header = NULL;
        $body = substr($content, $header_size);
        foreach ($headers as $i) {
            list($key, $val) = array_pad(explode(":", $i),2,"");
            if ($key == "x-response-time"){
                $header = $val;
            }
        }
    } catch (Exception $e) {
        $ss2log->ss2_log("Error posting data to Shieldsquare server [" . $e->getMessage() . "]", $ss_constants->ERROR);
        curl_close($curl);
        return $response_obj;
    }

    $ssresp = NULL;
    if ($content == NULL || empty($content) || $content === false) {
        $errormsg = curl_error($curl);
        $ss2log->ss2_log("Post data failed! " . $errormsg, $ss_constants->ERROR);
        $response_obj->message = $errormsg;
    } else {
        try {
            $response_obj->ss2resp = $body;
            $ssresp = json_decode($body);
        } catch (Exception $e) {
            $ss2log->ss2_log("API Server response is empty ! [" . $response_obj->message . "]", $ss_constants->ERROR);
            curl_close($curl);
            return $response_obj;
        }
    }
    if ($config_data->_enable_serverlog == "True" && $config_data->_mode == "Active") {
        $siemPacket = new SIEMLogs();
        $apiPacket = json_decode($post_data);

        if ($config_data->_server != null && $config_data->_port != null) {
            $server = $config_data->_server;
            $port = $config_data->_port;
        } else {
            $server = 0;
            $port = 0;
        }
        $xRespTime = "X-Response-Time";
        $error = curl_error($curl);
        $siemPacket->IP = $apiPacket->_zpsbd6;
        $siemPacket->UA = $apiPacket->_zpsbd7;
        $siemPacket->URL = $apiPacket->_zpsbd4;
        $siemPacket->Referrer = $apiPacket->_zpsbd3;
        $siemPacket->Session = $apiPacket->_zpsbd5;
        $siemPacket->Username = $apiPacket->_zpsbd9;
        $siemPacket->ResponseTime = $respTime;
        if ($error != "") {
            $siemPacket->Error = $error;
        } else {
            $siemPacket->$xRespTime = ($header != null || $header[1] != "") ? trim($header[1], " ") : "";
            $siemPacket->Response = $ssresp;
        }
        $loglevel = isset($config_data->_loglevel) ? $config_data->_loglevel : "Debug";
        printSIEM($siemPacket, $loglevel, $server, $port);
    }
    curl_close($curl);
    return $response_obj;
}

?>
