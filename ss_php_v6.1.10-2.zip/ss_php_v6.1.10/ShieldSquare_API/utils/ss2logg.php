<?php

class ss2Log
{
    public static $log_enabled = true;
    public static $log_dirname = '';

    public static function ss2_log($msg, $type)
    {
        $ss2log = new ss2Log();
        $ssconsts = new ShieldsquareConstants();
        $logdirectory = $ss2log::$log_dirname != '' ? $ss2log::$log_dirname : $ssconsts->log_dirname;
        $logfile_name = $logdirectory . $ssconsts->ERROR_LOG_FILE_NAME;
        $logfile_size = $ssconsts->ERROR_LOG_FILE_SIZE;
        $logfiletokeep = $ssconsts->ERROR_LOG_FILE_LIMIT;
        if (file_exists($logfile_name)) {
            if (filesize($logfile_name) > $logfile_size) {
                if (file_exists($logfile_name . "." . $logfiletokeep)) {
                    unlink($logfile_name . "." . $logfiletokeep);
                }
                for ($i = $logfiletokeep; $i > 0; $i--) {
                    if (file_exists($logfile_name . "." . $i)) {
                        $next = $i + 1;
                        rename($logfile_name . "." . $i, $logfile_name . "." . $next);
                    }
                }
                rename($logfile_name, $logfile_name . ".1");
            }
        }
        if ($ss2log::$log_enabled) {
            $date = gmdate('d.m.Y h:i:s');
            $log = "[" . $date . "] [ShieldSquare:" . $type . "] " . $msg . "\n";
            error_log($log, 3, $logfile_name);
        }
    }
}


?>
