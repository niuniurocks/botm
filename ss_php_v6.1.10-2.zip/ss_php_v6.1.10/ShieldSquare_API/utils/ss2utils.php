<?php
if (!function_exists('getallheaders')) {
    function getallheaders()
    {
        $headers = array();
        foreach ($_SERVER as $name => $value) {
            $headers[$name] = $value;
        }
        return $headers;
    }
}

function get_service_url($config, $req)
{
    $schema = $config->api_server_ssl_enabled == "True" ? 'https://' : 'http://';
    $ss2domain = $config->api_server_domain;
    $idn = $config->deployment_number;
    $serviceurl = $schema . $ss2domain . "/environments/" . $idn . "/" . $req;
    return $serviceurl;
}

function post_service_url($config)
{
    $schema = $config->_api_server_ssl_enabled == "True" ? 'https://' : 'http://';
    $ss2domain = $config->_api_server_domain;
    return $schema . $ss2domain . '/getRequestData';
}

function extensionfilter($config, $url)
{
    $ss2log = new ss2Log();
    $ss_constants = new ShieldsquareConstants();
    if ($config->_content_filter == "True") {
        $extensions = $config->_content_list;
        if ($extensions !== '' && (preg_match("/.(" . $extensions . ")$/", $url))) {
            $ss2log->ss2_log("Request not processed as extension added in request list: [$url]", $ss_constants->DEBUG);
            return true;
        }
    }
    return false;
}

function skipurlfilter($config, $url)
{
    $ss2log = new ss2Log();
    $ss_constants = new ShieldsquareConstants();
    $skipurlstring = $config->_skip_url_list;
    if ($skipurlstring !== '') {
        $skipurllist = explode(',', $skipurlstring);
    }
    $skipenabled = ($config->_skip_url == "True") ? true : false;
    if ($skipenabled && !empty($skipurllist)) {
        foreach ($skipurllist as $pattern) {
            if (preg_match("~" . trim($pattern) . "~", $url)) {
                $ss2log->ss2_log("Request not processed as it added in skip list: [$url]", $ss_constants->DEBUG);
                return true;
            }
        }
    }
    return false;
}

function generate_pid($shieldsquare_sid)
{
    $t = explode(" ", microtime());
    list($p1, $p2, $p3, $p4, $p5) = explode("-", $shieldsquare_sid);
    $sid_min = $p4;
    return strtolower(sprintf(
            '%04x%04x-%04s-%04s-%04s-%04x%04x%04x',
            mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            $sid_min,
            substr("00000000" . dechex($t[1]), -4),
            substr("0000" . dechex(round($t[0] * 65536)), -4),
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        )
    );
}

function get_request_ip($ipaddress_header)
{
    $ss2log = new ss2Log();
    $ss_constants = new ShieldsquareConstants();
    $request_IP = "";

    $allheaders = json_decode(json_encode(getallheaders()));

    if ($ipaddress_header == '') {
        $ipaddress_header = 'REMOTE_ADDR';
    }

    if ($ipaddress_header != 'Auto' && isset($allheaders->$ipaddress_header)) {
        $request_IP = $allheaders->$ipaddress_header;
    } else {
        $request_IP = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
    }
    return $request_IP;
}

function get_other_headers($config_data)
{
    $ss2log = new ss2Log();
    $ss_constants = new ShieldsquareConstants();
    $other_headers = new StdClass;
    foreach (getallheaders() as $header_name => $header_value) {
        $other_headers->{$header_name} = (string)(isset($header_name) ? $header_value : '');
    }
    if (isset($config_data->_blacklist_headers) && $config_data->_blacklist_headers != "") {
        $blacklistheaders = $config_data->_blacklist_headers;
        $black_headers = new StdClass;
        $blacklistheaders = explode(',', $blacklistheaders);
        foreach ($other_headers as $header_name => $header_value) {
            if (!in_array($header_name, $blacklistheaders)) {
                $black_headers->{$header_name} = (string)(isset($header_value) ? $header_value : '');
            }
        }
        $other_headers = $black_headers;
    } else {
        if (isset($config_data->_whitelist_headers) && $config_data->_whitelist_headers != "") {
            $whitelistheaders = $config_data->_whitelist_headers;
            $white_headers = new StdClass;
            $whitelistheaders = explode(',', $whitelistheaders);
            foreach ($other_headers as $header_name => $header_value) {
                if (in_array($header_name, $whitelistheaders)) {
                    $white_headers->{$header_name} = (string)(isset($header_value) ? $header_value : '');
                }
            }
            $other_headers = $white_headers;
        }
    }
    return $other_headers;
}

function validate_iSplitIP(&$apipacket, $ip_index)
{
    $reqIp = $apipacket->_zpsbd6;
    $splitIp = explode(",", $reqIp);
    $iSplitIP = "";
    if ($ip_index >= 0) {
        $start_index = ($ip_index == 0) ? 0 : $ip_index - 1;
        for ($i = $start_index; $i < count($splitIp); $i++) {
            $ip2check = trim($splitIp[$i], "^ ");
            if (is_valid_IP($ip2check)) {
                $iSplitIP = $ip2check;
                break;
            }
        }
    } else {
        for ($i = count($splitIp) + $ip_index; $i >= 0; $i--) {
            $ip2check = trim($splitIp[$i], "^ ");
            if (is_valid_IP($ip2check)) {
                $iSplitIP = $ip2check;
                break;
            }
        }
    }
    $cntColon = substr_count($iSplitIP, ':');
    if ($cntColon == 1) {
        $iSplitIP = explode(':', $iSplitIP);
        $iSplitIP = $iSplitIP[0];
    }
    $apipacket->_zpsbd6 = $iSplitIP;
}

function is_valid_IP($ipToValidate)
{
    $ss2log = new ss2Log();
    $ss_constants = new ShieldsquareConstants();
    if (isset($ipToValidate)) {
        $cntColon = substr_count($ipToValidate, ':');
        $cntPeriod = substr_count($ipToValidate, '.');
        if (!($cntColon > 1 || $cntPeriod == 3)) {
            return false;
        }
        if ($cntColon > 1) {
            if ($ipToValidate == '::1' || $ipToValidate == '0:0:0:0:0:0:0:0'
                || $ipToValidate == '::' || $ipToValidate == '::/128'
                || $ipToValidate == '0:0:0:0:0:0:0:1' || $ipToValidate == '::1/128') {
                return false;
            } elseif (preg_match('/^fd/', $ipToValidate) == 1) {
                return false;
            }
        } elseif ($cntPeriod == 3) {
            if ($cntColon == 1) {
                $ipToValidate = explode(':', $ipToValidate);
                $ipToValidate = $ipToValidate[0];
            }

            $ipToValidateLong = ip2long($ipToValidate);
            $ip2LongValues = set_ip2long_values();
            $checkIP = check_ip_range($ipToValidateLong, 1, $ip2LongValues);
            if ($checkIP) {
                return false;
            }
        }
    } else {
        $ss2log->ss2_log("IP Address is not set", $ss_constants->DEBUG);
        return false;
    }
    return true;
}

function set_ip2long_values()
{
    $ip2LongValues = array();
    $validIPRanges = new ShieldsquareValidIPRange();
    foreach ($validIPRanges as $key => $value) {
        $ip2LongValues[$key] = ip2long($value);
    }
    return $ip2LongValues;
}

function check_ip_range($ipToValidateLong, $i, $ip2LongValues)
{
    if (ceil((count($ip2LongValues) / 2) + 1) == $i) {
        return false;
    } else {
        $isValid = false;
        if (isset($ip2LongValues['minIP' . $i]) && isset($ip2LongValues['maxIP' . $i])) {
            $isValid = (($ipToValidateLong >= $ip2LongValues['minIP' . $i]) && ($ipToValidateLong <= $ip2LongValues['maxIP' . $i]));
        }
        return $isValid || check_ip_range($ipToValidateLong, $i + 1, $ip2LongValues);
    }
}

function validate_ajax_headers(&$apipacket)
{
    $apipacket->_zpsbdm = isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : '';
    $apipacket->_zpsbdxrw = isset($_SERVER['HTTP_X_REQUESTED_WITH']) ? $_SERVER['HTTP_X_REQUESTED_WITH'] : '';
}

function validate_IP_headers(&$apipacket, $deployment_number)
{
    $iheadersarray = array(
        "REMOTE_ADDR" => "i0",
        "X-Forwarded-For" => 'i1',
        "HTTP_CLIENT_IP" => 'i2',
        "HTTP_X_FORWARDED_FOR" => "i3",
        "x-real-ip" => "i4",
        "HTTP_X_REAL_IP" => "i4",
        "HTTP_X_FORWARDED" => "i5",
        "Proxy-Client-IP" => "i6",
        "HTTP_PROXY_CLIENT_IP" => "i6",
        "WL-Proxy-Client-IP" => "i7",
        "HTTP_WL_PROXY_CLIENT_IP" => "i7",
        "True-Client-IP" => "i8",
        "HTTP_TRUE_CLIENT_IP" => "i8",
        "HTTP_X_CLUSTER_CLIENT_IP" => "i9",
        "HTTP_FORWARDED_FOR" => "i10",
        "HTTP_FORWARDED" => "i11",
        "HTTP_VIA" => "i12",
        "X-True-Client-IP" => "i13",
        "HTTP_X_TRUE_CLIENT_IP" => "i13"
    );

    $allheaders = json_encode(getallheaders());
    $allheaders = json_decode($allheaders);

    foreach ($iheadersarray as $key => $value) {
        if (isset($allheaders->$key) && !isset($apipacket->$value)) {
            $apipacket->$value = $allheaders->$key;
        }
    }

    $ixffheader = "HTTP_X_FORWARDED_FOR";
    if (isset($allheaders->$ixffheader)) {
        $ixffheadervalue = $allheaders->$ixffheader;
        $x_forwarded_for = explode(',', $ixffheadervalue);
        foreach ($x_forwarded_for as $split_ip) {
            $split_ip = trim($split_ip, "^ ");
            if (is_valid_IP($split_ip)) {
                $cntColon = substr_count($split_ip, ':');
                if ($cntColon == 1) {
                    $split_ip = explode(':', $split_ip);
                    $split_ip = $split_ip[0];
                }
                $apipacket->ixff = $split_ip;
                break;
            }
        }
    }

    $apipacket->idn = (!empty($deployment_number)) ? $deployment_number : '1234';
}

function validate_proxy_authorization($apipacket)
{
    $allheaders = json_encode(getallheaders());
    $allheaders = json_decode($allheaders);
    $httpauth = 'HTTP_PROXY_AUTHORIZATION';
    if (isset($allheaders->$httpauth)) {
        $apipacket->_zpsbdpa = $allheaders->$httpauth;
    }
}

function validate_cookies(&$shieldsquare_request, $shieldsquare_time, $shieldsquare_ex_time, $config)
{
    $ss2log = new ss2Log();
    $ss_constants = new ShieldsquareConstants();
    $request_constants = new ShieldsquareRequestConstants();
    $shieldsquare_consts = new ShieldsquareConstants();
    $secure = false;
    if ($config->_is_secure == "True") {
        $secure = true;
    }

    $shieldsquare_uzma = isset($_COOKIE["__uzma"]) ? $_COOKIE["__uzma"] : "";
    $shieldsquare_uzmb = isset($_COOKIE["__uzmb"]) ? $_COOKIE["__uzmb"] : "";
    $shieldsquare_uzmc = isset($_COOKIE["__uzmc"]) ? $_COOKIE["__uzmc"] : "";
    $shieldsquare_uzmd = isset($_COOKIE["__uzmd"]) ? $_COOKIE["__uzmd"] : "";
    if ($shieldsquare_request->_zpsbd8 == $shieldsquare_consts->CALLTYPE_DEFAULT || $shieldsquare_request->_zpsbd8 == $shieldsquare_consts->MOBILE) {
        if (isset($_COOKIE["__uzma"]) && isset($_COOKIE["__uzmb"]) && isset($_COOKIE["__uzmc"]) && isset($_COOKIE["__uzmd"])) {
                $is_cookie_tampered = false;
                $uzmc_counter = substr($shieldsquare_uzmc,
                $request_constants->shieldsquare_e,
                (strlen($shieldsquare_uzmc) - $request_constants->shieldsquare_f));

            $shieldsquare_counter = ((int)$uzmc_counter - $request_constants->shieldsquare_c)
                / $request_constants->shieldsquare_b
                + $request_constants->shieldsquare_d;

            if (strlen($shieldsquare_uzma) != $shieldsquare_consts->UUID_LENGTH
                || !ctype_digit((string)$shieldsquare_uzmc)
                || !ctype_digit((string)$shieldsquare_uzmb)
                || strlen($shieldsquare_uzmc) < $shieldsquare_consts->UZMC_LENGTH
                || strlen($shieldsquare_uzmb) != $shieldsquare_consts->TIME_LENGTH
                || strlen($shieldsquare_uzmd) != $shieldsquare_consts->TIME_LENGTH
                || $shieldsquare_counter < $shieldsquare_consts->SS_COUNTER
                || ($shieldsquare_counter != floor($shieldsquare_counter))) {
                $is_cookie_tampered = true;
                $shieldsquare_counter = $shieldsquare_consts->SS_COUNTER;
                $shieldsquare_uzma = generate_uuid4();
                $shieldsquare_uzmb = (string)$shieldsquare_time;
            }

            $shieldsquare_uzmc = generate_uzmc($request_constants->shieldsquare_l,
                $request_constants->shieldsquare_h,
                $shieldsquare_counter,
                $request_constants->shieldsquare_b,
                $request_constants->shieldsquare_c);
            if ($is_cookie_tampered) {
                setcookie("__uzma", $shieldsquare_uzma, $shieldsquare_ex_time, '/', "", $secure, true);
                setcookie("__uzmb", $shieldsquare_uzmb, $shieldsquare_ex_time, '/', "", $secure, true);
                $ss2log->ss2_log("Cookie has been tempared", $ss_constants->DEBUG);
            }
        } else {
            $shieldsquare_uzma = generate_uuid4();
            $shieldsquare_uzmb = (string)$shieldsquare_time;
            $shieldsquare_uzmd = $shieldsquare_uzmb;
            $shieldsquare_uzmc = generate_uzmc($request_constants->shieldsquare_l,
                $request_constants->shieldsquare_h,
                $request_constants->shieldsquare_a,
                $request_constants->shieldsquare_b,
                $request_constants->shieldsquare_c);
            setcookie("__uzma", $shieldsquare_uzma, $shieldsquare_ex_time, '/', "", $secure, true);
            setcookie("__uzmb", $shieldsquare_time, $shieldsquare_ex_time, '/', "", $secure, true);
            $ss2log->ss2_log("Some cookie data is missed", $ss_constants->DEBUG);
        }

        $shieldsquare_uzmd = (string)$shieldsquare_time;
        setcookie("__uzmc", $shieldsquare_uzmc, $shieldsquare_ex_time, '/', "", $secure, true);
        setcookie("__uzmd", $shieldsquare_uzmd, $shieldsquare_ex_time, '/', "", $secure, true);
    }

    $shieldsquare_request->__uzma = $shieldsquare_uzma != null ? $shieldsquare_uzma : "";
    $shieldsquare_request->__uzmb = $shieldsquare_uzmb != null ? $shieldsquare_uzmb : "";
    $shieldsquare_request->__uzmc = $shieldsquare_uzmc != null ? $shieldsquare_uzmc : "";
    $shieldsquare_request->__uzmd = $shieldsquare_uzmd != null ? $shieldsquare_uzmd : "";

    if (($shieldsquare_request->_zpsbd8 == $shieldsquare_consts->MOBILE) || ($shieldsquare_request->_zpsbd8 == $shieldsquare_consts->CALLTYPE_DEFAULT && $config->_other_headers == "True")) {
        if (isset($_COOKIE["__uzme"])) {
            $shieldsquare_uzme = $_COOKIE["__uzme"];
        }
        else {
            list($p1, $p2, $p3, $p4, $p5) = explode("-", $shieldsquare_uzma);
            $shieldsquare_uzme = hexdec($p1) | hexdec($p4) ;
            if (strlen($shieldsquare_uzme) > 4) {
                $shieldsquare_uzme = substr($shieldsquare_uzme, -4);
            }
            setcookie("__uzme", $shieldsquare_uzme, $shieldsquare_ex_time, '/', "", $secure, true);
        }

        if (strlen($shieldsquare_uzme) > 4) {
            $shieldsquare_uzme = substr($shieldsquare_uzme, -4);
        }
        $shieldsquare_request->__uzme = $shieldsquare_uzme;
    }


    /* Update JS cookies to api data packet*/
    $js_cookiea = '/^__uzmaj/';
    $js_cookieb = '/^__uzmbj/';
    $js_cookiec = '/^__uzmcj/';
    $js_cookied = '/^__uzmdj/';
    foreach ($_COOKIE as $key=>$val) {
        if (preg_match($js_cookiea, $key)) {
            $shieldsquare_request->__uzmaj = $val;
        }
        else if (preg_match($js_cookieb, $key)) {
            $shieldsquare_request->__uzmbj = $val;
        }
        else if (preg_match($js_cookiec, $key)) {
            $shieldsquare_request->__uzmcj = $val;
        }
        else if (preg_match($js_cookied, $key)) {
            $shieldsquare_request->__uzmdj = $val;
        }
    }
}

function generate_uuid4()
{
    return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        mt_rand(0, 0xffff), mt_rand(0, 0xffff),
        mt_rand(0, 0xffff),
        mt_rand(0, 0x0fff) | 0x4000,
        mt_rand(0, 0x3fff) | 0x8000,
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
    );
}

function generate_uzmc($low, $high, $a, $b, $c)
{
    return (string)mt_rand($low, $high) . (string)($c + $a * $b) . (string)mt_rand($low, $high);
}

function generate_string($length, $characters)
{
    $string = '';
    for ($i = 0; $i < $length; $i++) {
        $string .= $characters[mt_rand(0, strlen($characters) - 1)];
    }
    return $string;
}

function generate_alternate_pid()
{
    $t = explode(" ", microtime());
    return sprintf(
        '%04x%04x-%04x-%04s-%04s-%04x%04x%04x',
        mt_rand(0, 0xffff), mt_rand(0, 0xffff),
        mt_rand(0, 0xffff),
        substr("00000000" . dechex($t[1]), -4),
        substr("0000" . dechex(round($t[0] * 65536)), -4),
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
    );
}

function generate_redirect_query($ss_request, $config_data, $e, $f, $custRespPage,$respCode)
{
    if ($custRespPage === true) {
        $page = ($respCode === 3) ? '/block?' : '/captcha?';
        $ssa = urlencode($ss_request->_zpsbd4);
        $ssb = hash('sha1', $ss_request->_zpsbd1 . $ss_request->_zpsbd4);
        $ssc = base64_encode(strrev($ss_request->_zpsbd1));
        $url = $page . "ssa=$ssa&ssb=$ssb&ssc=$ssc";
        return $url;
    }

    $constants = new ShielsquareQueryConstants();
    $uzmc_sequence = substr($ss_request->__uzmc, $e, strlen($ss_request->__uzmc) - $f);

    $ssa = generate_uuid4();
    $ssb = generate_string(5, $constants->digits) . $respCode . generate_string(5, $constants->digits);
    $ssc = urlencode($ss_request->_zpsbd4);
    $ssi = $ss_request->_zpsbd2;
    $ssk = $config_data->_support_email;
    $ssm = generate_string(17, $constants->digits) . (string)$uzmc_sequence . generate_string(13, $constants->digits);

    $inputDigest = $ss_request->_zpsbd1 . $ss_request->_zpsbd5
        . urldecode($ss_request->_zpsbd4) . (string)$uzmc_sequence
        . $ss_request->_zpsbd2 . $ss_request->_zpsbd7 . $ssk . $ss_request->_zpsbd6;

    $digest = hash('sha1', $inputDigest);

    if (strlen($ss_request->__uzma) <= 20) {
        $first_part_uzma = $ss_request->__uzma;
        $second_part_uzma = "";
    } else {
        $first_part_uzma = substr($ss_request->__uzma, 0, 20);
        $second_part_uzma = substr(
            $ss_request->__uzma, 20
            - strlen($ss_request->__uzma)
        );
    }

    $ssn = generate_string(8, $constants->charDigits) . substr($digest, 0, 20)
        . generate_string(8, $constants->charDigits) . $first_part_uzma
        . generate_string(5, $constants->charDigits);

    $sso = generate_string(5, $constants->charDigits) . $second_part_uzma
        . generate_string(8, $constants->charDigits) . substr($digest, -20)
        . generate_string(8, $constants->charDigits);

    $ssp = generate_string(10, $constants->digits) . substr($ss_request->__uzmb, 0, 5)
        . generate_string(5, $constants->digits) . substr($ss_request->__uzmd, 0, 5)
        . generate_string(10, $constants->digits);

    $ssq = generate_string(7, $constants->digits) . substr($ss_request->__uzmd, -5)
        . generate_string(9, $constants->digits) . substr($ss_request->__uzmb, -5)
        . generate_string(15, $constants->digits);


    $ssr = base64_encode(isset($ss_request->iSplitIP) ? $ss_request->iSplitIP : $ss_request->_zpsbd6);

    $sst = $ss_request->_zpsbd7;
    if ($ss_request->_zpsbd9 != null || $ss_request->_zpsbd9 != "") {
        $ssv = base64_encode($ss_request->_zpsbd9);
    } else {
        $ssv = $ss_request->_zpsbd9;
    }
    $ssw = $ss_request->_zpsbd5;


    return "/?ssa=$ssa" . "&ssb=$ssb" . "&ssc=$ssc" . "&ssi=$ssi" . "&ssk=$ssk" . "&ssm=$ssm" . "&ssn=$ssn" . "&sso=$sso"
        . "&ssp=$ssp" . "&ssq=$ssq" . "&ssr=$ssr" . "&sst=$sst"
        . "&ssv=$ssv" . "&ssw=$ssw";
}

function handle_sync($config_data, $url, $json, $curltime)
{
    $returncodes = new ShieldsquareCodes();
    $response = shieldsquare_sync($config_data, $url, $json, $curltime);
    if ($response->ss2resp == '') {
        return $returncodes->ALLOW_EXP;
    } else {
        $responsecode = json_decode($response->ss2resp);
        $ssresp = intval($responsecode->ssresp);
        return $ssresp;
    }
}

function handle_async($config_data, $url, $json, $curltime)
{
    shieldsquare_sync($config_data, $url, $json, $curltime);
    return 0;
}

function printSIEM($siemPacket, $loglevel, $server, $port)
{
    $siemLog = json_encode($siemPacket);
    $constants = new ShieldsquareConstants();
    if (!($server === 0 && $port === 0)) {
        error_reporting(~E_WARNING);
        if (!($sock = socket_create(AF_INET, SOCK_DGRAM, 0))) {
            $errorcode = socket_last_error();
            $errormsg = socket_strerror($errorcode);
            ss2Log::ss2_log("Couldn't create socket: [$errorcode] $errormsg \n", $constants->ERROR);
        }
        if (!socket_sendto($sock, $siemLog, strlen($siemLog), 0, $server, $port)) {
            $errorcode = socket_last_error();
            $errormsg = socket_strerror($errorcode);
            ss2Log::ss2_log("Could not send data: [$errorcode] $errormsg \n", $constants->ERROR);
        }
    } else {
        $loglevel = strtolower($loglevel);
        if ($loglevel == "debug") {
            ss2Log::ss2_log("SIEM Logs : " . $siemLog, $constants->DEBUG);
        } elseif ($loglevel == "info") {
            ss2Log::ss2_log("SIEM Logs : " . $siemLog, $constants->INFO);
        } elseif ($loglevel == "warn") {
            ss2Log::ss2_log("SIEM Logs : " . $siemLog, $constants->WARNING);
        } elseif ($loglevel == "err") {
            ss2Log::ss2_log("SIEM Logs : " . $siemLog, $constants->ERROR);
        } elseif ($loglevel == "notice") {
            ss2Log::ss2_log("SIEM Logs : " . $siemLog, $constants->NOTICE);
        }
    }

}

?>
