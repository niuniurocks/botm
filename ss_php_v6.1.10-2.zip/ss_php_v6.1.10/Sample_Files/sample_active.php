<?php
session_start();
// Code Snippet for Shield Square
include '../ShieldSquare_API/ss2.php';

$username = "Sample Username";
$shieldsquare_response = shieldsquare_validaterequest($username);
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
        "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Content-Language" content="en" />
<title>Sample Home Page</title>
</head>
<body>
<?php
if ($shieldsquare_response->responsecode == 0) {
	echo "Allow the user request";
}
elseif ($shieldsquare_response->responsecode == 1) {
	echo "Monitor this Traffic";
}
elseif ($shieldsquare_response->responsecode == 2) {
	echo "Show CAPTCHA before displaying the content";
}
elseif ($shieldsquare_response->responsecode == 3) {
	echo "Block This request";
}
elseif ($shieldsquare_response->responsecode == 4) {
	echo "Feed Fake Data";
}
elseif ($shieldsquare_response->responsecode == -1) {
	echo "Curl Error - " . $shieldsquare_response->reason . "<BR>";
	echo "Please reach out to ShieldSquare support team for assistance <BR>";
	echo "Allow the user request";
}
?>

<!--
<script>
  ShieldSquare JavaScript Integration Here
</script>
-->

<h1>
	<BR>YOUR CODE GOES HERE
</h1>
</body>
</html>
